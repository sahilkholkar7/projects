<div >
  <h2>Payments</h2>
  <table class="table ">
    <thead>
      <tr>
        <th class="text-center">PayID</th>
        <th class="text-center">Amount</th>
        <!-- <th class="text-center">CustID</th>
        <th class="text-center">CarID</th> -->
        <!-- <th class="text-center">Address</th> -->
        <!-- <th class="text-center">Joining Date</th> -->
      </tr>
    </thead>
    <?php
      include_once "../config/dbconnect.php";
      $sql="SELECT * from payment";
      $result=$conn-> query($sql);
      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
           
    ?>
    <tr>
      <td><?=$count?></td>
      <td><?=$row["amount"]?></td>
    </tr>
    <?php
            $count=$count+1;
           
        }
    }
    ?>
  </table>