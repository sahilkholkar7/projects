<div >
  <h2>Records</h2>
  <table class="table ">
    <thead>
      <tr>
        <th class="text-center">CarID</th>
        <th class="text-center">BookID</th>
        <th class="text-center">Date</th>
        <!-- <th class="text-center">CarID</th> -->
        <!-- <th class="text-center">Address</th> -->
        <!-- <th class="text-center">Joining Date</th> -->
      </tr>
    </thead>
    <?php
      include_once "../config/dbconnect.php";
      $sql="SELECT * from record";
      $result=$conn-> query($sql);
      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
           
    ?>
    <tr>
      <td><?=$count?></td>
      <td><?=$row["car_id"]?></td>
      <td><?=$row["book_id"]?></td>
      <td><?=$row["date"]?></td>
    </tr>
    <?php
            $count=$count+1;
           
        }
    }
    ?>
  </table>