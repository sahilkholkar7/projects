<div >
  <h2>All Cars</h2>
  <table class="table ">
    <thead>
      <tr>
        <th class="text-center">Car ID</th>
        <th class="text-center">Car name</th>
        <!-- <th class="text-center">Lname</th> -->
        <th class="text-center">Price</th>
        <th class="text-center">Capacity</th>
        <!-- <th class="text-center">Joining Date</th> -->
      </tr>
    </thead>
    <?php
      include_once "../config/dbconnect.php";
      $sql="SELECT * from car";
      $result=$conn-> query($sql);
      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
           
    ?>
    <tr>
      <td><?=$count?></td>
      <td><?=$row["car_id"]?></td>
      <td><?=$row["car_name"]?></td>
      <td><?=$row["price"]?></td>
      <td><?=$row["capacity"]?></td>
    </tr>
    <?php
            $count=$count+1;
           
        }
    }
    ?>
  </table>