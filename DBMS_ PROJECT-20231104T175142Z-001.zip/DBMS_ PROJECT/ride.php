<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Rental Website</title>
    <!-- css link -->
    <link rel="stylesheet" href="ride.css">
    <!-- Box icon -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <script src="https://kit.fontawesome.com/20af9b7f0f.js" crossorigin="anonymous"></script>
</head>
<body>

 <?php
    require('db.php');
     session_start();
    

if ($_SERVER["REQUEST_METHOD"] === "POST") {
 
  $date = mysqli_real_escape_string($con, $_POST['date']);
  $place = mysqli_real_escape_string($con, $_POST['place']);


  $query = "INSERT INTO booking (book_date,book_place) 
            VALUES ('$date','$place')";
  $result = mysqli_query($con, $query);

  if ($result) {
      echo "Booking successful.";
  } else {
      echo "Error: Unable to book. Please try again.";
  }
}
?> 





    
    <header>
        <a href="#" class="logo"><img src="img/jeep.png" alt=""></a>
        <h4>Car Rent</h4>

        <div class="bx bx-menu" id="menu-icon"></div>

        <ul class="navbar">
            <li><a href="home.html">Home</a></li>
            <li><a href="ride.php">Ride</a></li>
            <li><a href="services.html">Service</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="reviews.html">Review</a></li>
        </ul>
        <div class="header-btn">
            <a href="login_page.php" class="sign-up">Login</a>
            <a href="sign_up.php" class="sign-in">Sign In</a>
            <a href="emp_login.php" class="admin">Admin</a>
        </div>
    </header>
    <br><br>

    <section class="services" id="services">
    <div class="heading">
        <span>Best Services</span>
        <h1>Explore Our Top Deals <br> From Top Rated Dealers</h1>
    </div>

    <div class="services-container">
    <div class="box">
            <div class="box-img">
                <img src="img/car-2.jpg" alt="">
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h3>capacity: 4</h3>
            <h2>Rs.5000<span>/day</span></h2>
            <form class="form" method="post" name="payment">
            <h3>select date:</h3>
                <input type="date" name="date" value="<?php echo $date; ?>">
                <br>
                <h3><label for="place">Select a Place:</label></h3>
                <select id="place" class="login-input" name="place">
                    <option value="Margoa">Margoa</option>
                    <option value="Panaji">Panaji</option>
                    <option value="Mapusa">Mapusa</option>
                </select>
                <input type="submit" value="Submit" class="btn">
            </form>
            <a href="payment.php?car=2018 Honda Civic&price=5000" class="btn">Rent Now</a>
        </div>

        <div class="box">
            <div class="box-img">
                <img src="img/car-2.jpg" alt="">
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h3>capacity: 4</h3>
            <h2>Rs.5000<span>/day</span></h2>
            <form class="form" method="post" name="payment">
            <h3>select date:</h3>
                <input type="date" name="date" value="<?php echo $date; ?>">
                <br>
                <h3><label for="place">Select a Place:</label></h3>
                <select id="place" class="login-input" name="place">
                    <option value="Margoa">Margoa</option>
                    <option value="Panaji">Panaji</option>
                    <option value="Mapusa">Mapusa</option>
                </select>
                <input type="submit" value="Submit" class="btn">
            </form>
            <a href="payment.php?car=2018 Honda Civic&price=5000" class="btn">Rent Now</a>
        </div>
        
      
        <div class="box">
            <div class="box-img">
                <img src="img/car-2.jpg" alt="">
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h3>capacity: 4</h3>
            <h2>Rs.5000<span>/day</span></h2>
            <form class="form" method="post" name="payment">
            <h3>select date:</h3>
                <input type="date" name="date" value="<?php echo $date; ?>">
                <br>
                <h3><label for="place">Select a Place:</label></h3>
                <select id="place" class="login-input" name="place">
                    <option value="Margoa">Margoa</option>
                    <option value="Panaji">Panaji</option>
                    <option value="Mapusa">Mapusa</option>
                </select>
                <input type="submit" value="Submit" class="btn">
            </form>
            <a href="payment.php?car=2018 Honda Civic&price=5000" class="btn">Rent Now</a>
        </div>

        <div class="box">
            <div class="box-img">
                <img src="img/car-2.jpg" alt="">
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h3>capacity: 4</h3>
            <h2>Rs.5000<span>/day</span></h2>
            <form class="form" method="post" name="payment">
            <h3>select date:</h3>
                <input type="date" name="date" value="<?php echo $date; ?>">
                <br>
                <h3><label for="place">Select a Place:</label></h3>
                <select id="place" class="login-input" name="place">
                    <option value="Margoa">Margoa</option>
                    <option value="Panaji">Panaji</option>
                    <option value="Mapusa">Mapusa</option>
                </select>
                <input type="submit" value="Submit" class="btn">
            </form>
            <a href="payment.php?car=2018 Honda Civic&price=5000" class="btn">Rent Now</a>
        </div>
        <div class="box">
            <div class="box-img">
                <img src="img/car-2.jpg" alt="">
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h3>capacity: 4</h3>
            <h2>Rs.5000<span>/day</span></h2>
            <form class="form" method="post" name="payment">
            <h3>select date:</h3>
                <input type="date" name="date" value="<?php echo $date; ?>">
                <br>
                <h3><label for="place">Select a Place:</label></h3>
                <select id="place" class="login-input" name="place">
                    <option value="Margoa">Margoa</option>
                    <option value="Panaji">Panaji</option>
                    <option value="Mapusa">Mapusa</option>
                </select>
                <input type="submit" value="Submit" class="btn">
            </form>
            <a href="payment.php?car=2018 Honda Civic&price=5000" class="btn">Rent Now</a>
        </div>
        <div class="box">
            <div class="box-img">
                <img src="img/car-2.jpg" alt="">
            </div>
            <p>2017</p>
            <h3>2018 Honda Civic</h3>
            <h3>capacity: 4</h3>
            <h2>Rs.5000<span>/day</span></h2>
            <form class="form" method="post" name="payment">
            <h3>select date:</h3>
                <input type="date" name="date" value="<?php echo $date; ?>">
                <br>
                <h3><label for="place">Select a Place:</label></h3>
                <select id="place" class="login-input" name="place">
                    <option value="Margoa">Margoa</option>
                    <option value="Panaji">Panaji</option>
                    <option value="Mapusa">Mapusa</option>
                </select>
                <input type="submit" value="Submit" class="btn">
            </form>
            <a href="payment.php?car=2018 Honda Civic&price=5000" class="btn">Rent Now</a>
        </div>
    </div>
</section>


    

    <div class="copyright">
      <p>&#169 Carrent All Right Reserved</p>
      <div class="social">
          <a href="#"><i class="fa-brands fa-facebook"></i></a>
          <a href="#"><i class="fa-brands fa-instagram"></i></a>
          <a href="#"><i class="fa-brands fa-twitter"></i></a>
      </div>
    </div>

  <script type="text/javascript" src="main.js"></script>
  </form>
</body>
</html>